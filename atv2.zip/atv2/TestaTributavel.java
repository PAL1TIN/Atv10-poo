package atv2;

public class TestaTributavel {
	public static void main(String[] args) {

		Cliente c1 = new Cliente("64538907325", "julia");

		ContaCorrente Cc = new ContaCorrente(202301, 76589, c1, 244, 999.0);
		SeguroDeVida Sv = new SeguroDeVida();

		GerenciadorDeImpostoDeRenda gerenciador = new GerenciadorDeImpostoDeRenda();

		gerenciador.adiciona(Cc);
		gerenciador.adiciona(Sv);

		System.out.println("Total de tributos: " + gerenciador.getTotal());
		Cc.debitaValor(51.99, 244);
		Cc.ImprimeSaldo();
	}

}
