package atv2;

public interface Tributavel {
	
	double calculaTributos();
}
