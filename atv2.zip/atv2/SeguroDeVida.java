package atv2;

public class SeguroDeVida implements Tributavel {

	public double calculaTributos() {
		return 42;

	}
}
